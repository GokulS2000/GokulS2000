package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class projectp2 extends AppCompatActivity {
    TextView login;
    EditText email,passw,conpassw;
    Button reg;
    ProgressDialog progressDialog;
    FirebaseAuth mAuth;
    FirebaseUser mUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_projectp2);
        TextView login=findViewById(R.id.login);

        login=findViewById(R.id.login);
        email=findViewById(R.id.username);
        passw=findViewById(R.id.password);
        conpassw=findViewById(R.id.cnfmpassword);
        reg=findViewById(R.id.register);
        progressDialog=new ProgressDialog(this);

        mAuth=FirebaseAuth.getInstance();
        mUser=mAuth.getCurrentUser();



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(projectp2.this,MainActivity.class));
            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Auth();
            }
        });
    }

    private void Auth() {
        String getemail = email.getText().toString();
        String getpass = passw.getText().toString();
        String confpassw = conpassw.getText().toString();


        if (passw.length() < 6) {
            passw.setError("Enter proper password");
        }else if (! passw.equals(confpassw)){
            conpassw.setError("Password not matching");
        }else{
            progressDialog.setMessage("Wait while registering");
            progressDialog.setTitle("Registration");
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();

            mAuth.createUserWithEmailAndPassword(getemail,getpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        progressDialog.dismiss();
                        sendUserToNextActivity();
                        Toast.makeText(projectp2.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                    }else{
                        progressDialog.dismiss();
                        Toast.makeText(projectp2.this, ""+task.getException(), Toast.LENGTH_SHORT).show();
                    }
                }
            });




        }
    }

    private void sendUserToNextActivity() {
        Intent intent=new Intent(projectp2.this,HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


}